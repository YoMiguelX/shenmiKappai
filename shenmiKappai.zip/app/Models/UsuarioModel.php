<?php
namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table            = 'usuario'; // <- Nombre real de tu tabla en la BD
    protected $primaryKey       = 'ID_USUARIO'; // <- Tu clave primaria si se llama así

    protected $allowedFields = [
    'TIPO_DOCUMENTO',
    'DOC_USUARIO',
    'NOMBRE_USUARIO',
    'APELLIDO_USUARIO',
    'TEL_USUARIO',
    'CORREO_USUARIO',
    'CONTRASENA',
    'ESTADO_USUARIO',
    'FECHA_CREACION',
    'rol_ID_ROL'
];

}
