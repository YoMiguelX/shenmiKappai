<?php

namespace App\Controllers;
use App\Models\UsuarioModel;

class Login extends BaseController
{
    public function index()
    {
        return view('/paginas/login'); 
    }

    public function acceder()
    {
        $correo = $this->request->getPost('correo');
        $contrasena = $this->request->getPost('contrasena');

        $modelo = new UsuarioModel();
        $usuario = $modelo->where('correo_usuario', $correo)->first();

        if ($usuario) {
            // Verificar la contraseña encriptada
            if (password_verify($contrasena, $usuario['CONTRASENA'])) {

                // Guardar en la sesión
                session()->set('usuario', $usuario['NOMBRE_USUARIO']);
                session()->set('rol', $usuario['rol_ID_ROL']); // O el nombre real de la columna

                // Redirigir según el rol
                switch ($usuario['rol_ID_ROL']) {
                    case 1: return redirect()->to('/admin');
                    case 2: return redirect()->to('/usuario');
                    case 3: return redirect()->to('/otroRol');
                    default: return redirect()->to('/');
                }

            } else {
                return redirect()->back()->with('msg', 'Contraseña incorrecta');
            }
        } else {
            return redirect()->back()->with('msg', 'Correo no registrado');
        }
    }

    public function restablecer()
    {
        return view('/paginas/restablecer');
    }

    public function salir()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
