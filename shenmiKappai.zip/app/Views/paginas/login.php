<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Inicio de Sesión - Juego Educativo</title>
    <link rel="stylesheet" href="SRC.2/CSS/login.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <button onclick="history.back()" type="button" class="btn btn-danger btn-volver">
        Volver
        </button>

    <div class="contenedor">
        <div class="formulario">
            <h1>¡Bienvenido a Shenmi!</h1>
            <p>Ingresa a las filas del aprendizaje noble usuario.</p>
            <form>
                <input type="email" placeholder="Correo electrónico" required />
                <input type="password" placeholder="Contraseña" required />
                <button type="submit">Iniciar sesión</button>
            </form>
            <div class="acciones">
                <a href="<?= base_url('/restablecer'); ?>">¿Olvidaste tu contraseña?</a> 
                <a href="<?= base_url('/registro'); ?>">Registrarme</a>
            </div>
        </div>
    </div>
</body>

</html>