<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Restablecer Contraseña</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="SRC.2/CSS/restablecer.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

    <div class="container">
        <h1>Restablecimiento de contraseña</h1>
        <p>Ingresa tu <strong>correo electrónico</strong> o <strong>nombre de usuario</strong> para enviarte un enlace
            de restablecimiento.</p>

        <form action="login.html" method="get">
            <label for="email">Dirección de correo electrónico o nombre de usuario</label>
            <input type="email" id="email" name="email" placeholder="Ej: usuario@correo.com" required>
            <button type="submit">ENVIAR</button>
        </form>

        <div class="ayuda">
            Si aún necesitas ayuda, ponte en contacto con el <a href="#">soporte técnico</a>
        </div>
    </div>

</body>

</html>