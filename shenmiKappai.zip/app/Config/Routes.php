<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('/Registro', 'Home::registro');
$routes->get('/login', 'Login::index');
$routes->post('/login/acceder', 'Login::acceder');
$routes->get('/logout', 'Login::salir');
$routes->get('/registro', 'Registro::index');         // Muestra el formulario de registro
$routes->post('/registro/guardar', 'Registro::guardar'); // Procesa el registro
$routes->get('/registro', 'Usuario::registro');
$routes->get('restablecer', 'Login::restablecer');