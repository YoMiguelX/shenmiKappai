<@php

namespace {namespace};

use CodeIgniter\Test\CIUnitTestCase;

class {class} extends CIUnitTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
    }

    public function testExample(): void
    {
        //
    }
}
